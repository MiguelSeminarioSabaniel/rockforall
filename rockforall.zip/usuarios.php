<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Creación de Tabla Usuarios</title>
</head>
<body>
    <?php
    $servername = "localhost";
    $dbname = "rockforall";

    // Conexión con la base de datos
    $conn = new mysqli($servername, "root", "", $dbname);

    // Verificar la conexión
    if ($conn->connect_error) {
        die("Error de conexión: " . $conn->connect_error);
    }

    // Crear la tabla de usuarios
    $sqlUsuarios = "CREATE TABLE usuarios (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nombre VARCHAR(30) NOT NULL,
        contrasena VARCHAR(255) NOT NULL
    )";

    // Insertar usuarios de ejemplo
    $sqlInsertAdmin = "INSERT INTO usuarios (nombre, contrasena)
                      VALUES ('Admin', '" . password_hash('admin', PASSWORD_DEFAULT) . "')";

    $sqlInsertMiguel = "INSERT INTO usuarios (nombre, contrasena)
                        VALUES ('Miguel', '" . password_hash('123', PASSWORD_DEFAULT) . "')";

    // Ejecutar la consulta
    if ($conn->query($sqlUsuarios) === TRUE &&
        $conn->query($sqlInsertAdmin) === TRUE &&
        $conn->query($sqlInsertMiguel) === TRUE) {
        echo "Tabla de usuarios creada y usuarios de ejemplo insertados exitosamente.";
    } else {
        echo "Error al crear la tabla de usuarios: " . $conn->error;
    }

    // Cerrar la conexión a la base de datos
    $conn->close();
    ?>
</body>
</html>