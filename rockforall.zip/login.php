<!-- login.php -->
<!DOCTYPE html>
<html>
<head>
    <title>Iniciar Sesión</title>
</head>
<body>

    <h2>Iniciar Sesión</h2>
    <form action="validar.php" method="post">
        <label for="username">Nombre de Usuario:</label>
        <input type="text" id="username" name="username" required><br>

        <label for="password">Contraseña:</label>
        <input type="password" id="password" name="password" required><br>

        <input type="submit" value="Iniciar Sesión">
    </form>
    <br><br><br>
    [usuario]Admin   [contraseña]Admin
    <br><br>
    [usuario]Miguel   [contraseña]123

</body>

<style>

    h2 {
        text-align: center;
    }

        body {
            background-image: url('logo.jpg'); /* Reemplaza 'ruta_de_tu_imagen.jpg' con la ruta correcta de tu imagen */
            background-repeat: no-repeat; /* Evita que la imagen de fondo se repita */
            background-size: 100%; /* Ajusta el tamaño de la imagen para cubrir toda la pantalla */
            text-align: center;
            justify-content: center;
            height: 10vh;
            margin: 0;
            color: white;
        }


    </style>
</html>