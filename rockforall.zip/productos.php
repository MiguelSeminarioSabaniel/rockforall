<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Creacion de Tabla Productos</title>
</head>
<body>
    <?php
    $servername = "localhost";
    $dbname = "rockforall";

    // Conexión con la base de datos
    $conn = new mysqli($servername, "root", "", $dbname);

    // Verificar la conexión
    if ($conn->connect_error) {
        die("Error de conexión: " . $conn->connect_error);
    }

    // Crear la tabla de productos
    $sqlProductos = "CREATE TABLE productos (
        id INT AUTO_INCREMENT PRIMARY KEY,
        Album VARCHAR(30) NOT NULL,
        Grupo VARCHAR(30) NOT NULL,
        Descripcion VARCHAR(100),
        Imagen VARCHAR(10),
        Precio DECIMAL(5,2),
        FechaCreacion DATE,
        FechaActualizacion DATE
    )";

    // Ejecutar la consulta
    if ($conn->query($sqlProductos) === TRUE) {
        echo "Tabla de productos creada exitosamente.";
    } else {
        echo "Error al crear la tabla de productos: " . $conn->error;
    }

    // Cerrar la conexión a la base de datos
    $conn->close();
    ?>
</body>
</html>