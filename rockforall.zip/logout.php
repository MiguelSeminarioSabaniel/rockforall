<!-- logout.php -->
<?php
session_start();

// Cerrar sesión
session_unset();
session_destroy();
header("Location: login.php");
exit;
?>