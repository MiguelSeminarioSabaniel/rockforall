<!-- validar.php -->
<?php
session_start();

$servername = "localhost";
$dbname = "rockforall";

// Conexión con la base de datos
$conn = new mysqli($servername, "root", "", $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Obtener las credenciales del formulario
$username = $_POST['username'];
$password = $_POST['password'];

// Consulta para verificar las credenciales en la base de datos
$sql = "SELECT id, nombre, contrasena FROM usuarios WHERE nombre = '$username'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $hashed_password = $row['contrasena'];

    // Verificar la contraseña
    if (password_verify($password, $hashed_password)) {
        // Credenciales válidas, iniciar sesión
        $_SESSION['loggedin'] = true;
        $_SESSION['user_id'] = $row['id'];
        $_SESSION['username'] = $row['nombre'];
        header("Location: rockforall.php"); // Redirigir a la página deseada después de iniciar sesión
    } else {
        echo 'Credenciales incorrectas. <a href="login.php">Intentar de nuevo</a>';
    }
} else {
    echo 'Credenciales incorrectas. <a href="login.php">Intentar de nuevo</a>';
}

// Cerrar la conexión a la base de datos
$conn->close();
?>