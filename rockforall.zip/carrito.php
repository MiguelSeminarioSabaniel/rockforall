<?php
session_start();

// Inicializa el carrito si no existe
if (!isset($_SESSION['carrito'])) {
    $_SESSION['carrito'] = array();
}

// Verifica si se ha enviado un producto desde rockforall.php
if (isset($_POST['producto_id'])) {
    // Recupera la información del producto desde el formulario
    $product_id = $_POST['producto_id'];
    $grupo = $_POST['group'];
    $album = $_POST['album'];
    $precio = $_POST['precio'];

    // Crea un array para el producto
    $producto = array(
        'producto_id' => $product_id,
        'grupo' => $grupo,
        'album' => $album,
        'precio' => $precio
    );

    // Agrega el producto al carrito
    $_SESSION['carrito'][] = $producto;
}

// Elimina un producto del carrito si se ha enviado un comando de eliminación
if (isset($_POST['eliminar_producto'])) {
    $eliminar_id = $_POST['eliminar_producto'];

    // Encuentra y elimina el producto del carrito por su ID
    foreach ($_SESSION['carrito'] as $key => $producto) {
        if ($producto['producto_id'] == $eliminar_id) {
            unset($_SESSION['carrito'][$key]);
            break; // Termina el bucle una vez que se elimina el producto
        }
    }
}

// En este punto, $_SESSION['carrito'] contiene todos los productos en el carrito
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrito</title>
</head>
<header><h1>Tu carrito de compra</h1></header>
<body>

    <?php
    // Muestra los productos en el carrito
    if (!empty($_SESSION['carrito'])) {
        echo "<ul>";
        foreach ($_SESSION['carrito'] as $producto) {
            echo "<li>ID: " . $producto['producto_id'] . "</li>";
            echo "<li>Álbum: " . $producto['album'] . "</li>";
            echo "<li>Grupo: " . $producto['grupo'] . "</li>";
            echo "<li>Precio: $" . $producto['precio'] . "</li>";
            
            // Añade un formulario para eliminar el producto del carrito
            echo "<form  method='post' action='carrito.php'>";
            echo "<input type='hidden' name='eliminar_producto' value='" . $producto['producto_id'] . "'>";
            echo "<input type='submit' value='Eliminar'>";
            echo "</form>";

            echo "<hr>";
        }
        echo "</ul>";
    } else {
        echo "<p>El carrito está vacío.</p>";
    } 
    echo "<br>";
    echo "<a href='rockforall.php'><img src='salir.jpg' alt='Cerrar Sesión'></a>";
    echo "<br>";
    echo "<a href='VaciarCarrito.php'><img src='carrito.jpg' alt='Vaciar Carrito'></a>";

    ?>
</body>
<style>
header {
    background-color: #333;
    padding: 10px;
    color: white;
}

body {
    background-image: url('fondo.png');
    background-size: cover;
    background-repeat: no-repeat;
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
}

li {
    color: #526EFD;
}

img {
    max-width: 100px;
    height: auto;
}

</style>
</html>