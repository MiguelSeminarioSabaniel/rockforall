<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RockForAll</title>
</head>

<body>

    <?php
    session_start();

    // Verificar si el usuario ha iniciado sesión
    if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
        header("Location: login.php");
        exit;
    }  

    // El usuario ha iniciado sesión, mostrar el contenido protegido
    ?>

     <?php
      include('head.php')
     ?>

    <?php
     include('conbasedatos.php');
     $sql = "SELECT * FROM productos";
     $result = $conn->query($sql);

     echo "</br>";
    

     echo "<div id='productos'>";

     $row_count = $result->num_rows;
    
     if ($result->num_rows > 0) {
   
        echo "<table border='1'>";
        echo "<tr>
                <th>ID</th>
                <th>Album</th>
                <th>Grupo</th>
                <th>Descripción</th>
                <th>Imagen</th>
                <th>Precio</th>
                <th>Fecha de Creación</th>
                <th>Fecha Actualizada</th>
                <th>Añadir al Carrito</th>
              </tr>";

      while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>". $row['id'] . "</td>";
        echo "<td>" . $row['Album'] . "</td>";
        echo "<td>" . $row['Grupo'] . "</td>";
        echo "<td> " . $row['Descripcion'] . "</td>";
        echo "<td> <img src='" . $row['Imagen'] . "' alt='Imagen del producto'></td>";
        echo "<td>" . $row['Precio'] . "</td>";
        echo "<td>" . $row['Fecha_Creacion'] . "</td>";
        echo "<td>" . $row['Fecha_Actualizada'] . "</td>";
        
        
        echo "<td>";
        echo "<form method='post' action='carrito.php'>";
        echo "<input type='hidden' name='producto_id' value='" . $row['id'] . "'>";
        echo "<input type='hidden' name='group' value='" . $row['Grupo'] . "'>";
        echo "<input type='hidden' name='album' value='" . $row['Album'] . "'>";
        echo "<input type='hidden' name='precio' value='" . $row['Precio'] . "'>";
        echo "<input type='submit' name='add_to_cart' value='Añadir al carrito'>";
        echo "</form>";
        echo "</td>";
        echo "</tr>";
    }

    echo "</table>";
    
    echo "</br>";
    echo "<a href='vaciar.php'><img src='carrito.jpg' alt='Vaciar Carrito'></a>";
    echo "</br></br>";
    echo "<a href='logout.php'><img src='salir.jpg' alt='Cerrar Sesión'></a>";
}
     ?>
</body>

<style>

    header {
        background-color: #333;
        padding: 10px;
        color: white;
        display: flex; /* Usar flexbox para alinear elementos */
        justify-content: space-between; /* Distribuir elementos a los extremos */
        align-items: center; /* Centrar verticalmente los elementos */
        }

        .logo {
        max-width: 100px; /* Ajustar según tus necesidades */
        }

        body {
        background-image: url('fondo.png'); /* Reemplaza 'ruta_de_tu_imagen.jpg' con la ruta correcta de tu imagen */
        background-size: cover; /* Ajusta el tamaño de la imagen para cubrir toda la pantalla */
        background-repeat: no-repeat; /* Evita que la imagen de fondo se repita */
        margin: 0; /* Elimina el margen predeterminado del body */
        padding: 0; /* Elimina el relleno predeterminado del body */
        font-family: Arial, sans-serif; /* Establece una fuente predeterminada para el contenido */
        }    

        #productos {
            margin: 20px;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        img {
            max-width: 100px; /* Ajusta el tamaño máximo de la imagen */
            height: auto;
        }

        form {
            display: inline; /* Alinea los formularios en línea */
        }

        tr {
            color: #9626FF; /* Cambia el color de fondo de las filas pares */
        }

        tr {
        background-image: url('logo.jpg');
        background-size: cover; 
        }

        .carrito-link {
        display: block; /* Asegúrate de que el enlace sea un bloque para poder aplicar márgenes y alineaciones */
        text-align: right; /* Ajusta el margen izquierdo según tus necesidades */
        margin: 10px;
        }

    </style>

</html>
      