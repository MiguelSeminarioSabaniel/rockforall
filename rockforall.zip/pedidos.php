<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Creación de Tabla Pedidos</title>
</head>
<body>
    <?php
    $servername = "localhost";
    $dbname = "rockforall";

    // Conexión con la base de datos
    $conn = new mysqli($servername, "root", "", $dbname);

    // Verificar la conexión
    if ($conn->connect_error) {
        die("Error de conexión: " . $conn->connect_error);
    }

    // Crear la tabla de pedidos
    $sqlPedidos = "CREATE TABLE pedidos (
        id INT AUTO_INCREMENT PRIMARY KEY,
        usuario_id INT NOT NULL,
        producto_id INT NOT NULL,
        cantidad INT NOT NULL,
        fecha_pedido DATE,
        FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
        FOREIGN KEY (producto_id) REFERENCES productos(id)
    )";

    // Ejecutar la consulta
    if ($conn->query($sqlPedidos) === TRUE) {
        echo "Tabla de pedidos creada exitosamente.";
    } else {
        echo "Error al crear la tabla de pedidos: " . $conn->error;
    }

    // Cerrar la conexión a la base de datos
    $conn->close();
    ?>
</body>
</html>