 <?php

      $conn = new mysqli("localhost", "root", "", "rockforall");

      

      if ($conn->connect_error) {
        die("Error de conexión: " . $conn->connect_error);
    }

?>

