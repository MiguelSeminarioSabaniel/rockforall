<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cabecera</title>
</head>
<body>
    <header><img src="logo.jpg" alt="logo" class="logo" />
        <h1>Tienda RockForAll</h1>
    <a href='carrito.php' class='carrito-link'><img src='ircarrito.jpg' alt='carrito'></a>
    </header>
     <?php
      
    ?>
</body>
</html>